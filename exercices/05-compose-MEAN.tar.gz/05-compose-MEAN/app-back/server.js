const express = require('express')
const cors = require('cors')
const app = express()
const corsOptions={
    origin:'https//app-front.docker.localhost',
    optionsSuccesStatus: 200
}

app.use(cors(corsOptions))
app.use(express.json())

app.route('/').get((req,res)=>{
    res.send(200, {
        message:"Hello World from docker:)"
    })
})

app.listen(3000, ()=>{
    console.log('Server started')
})